#include <iostream> 
using namespace std; 

// node structure here 

class List { 
    void push(int val); 
};

void List::push(int val) { 
    node *temp = new node;      // create new node 
    temp->val = val;
    temp->next = NULL; 

    if (head == NULL) {         // for when list is empty
        head = temp; 
        last = temp; 
    } else {                    // for all other cases 
        last->next = temp; 
        last = last->next; 
    } 
}

int main() { 
    // Part - 1 Starts here ----------------------
    List l; 

    l.push(5);          
    l.print_list(); 

    l.push(15);
    l.push(30);
    l.print_list(); 

    // Part - 1 Ends here ----------------------



    // Part - 2 Starts here ----------------------

    // cout << "Poppping: " << l.pop() << endl; 
    // l.print_list(); 

    // cout << "Poppping: " << l.pop() << endl; 
    // l.print_list(); 

    //// cout << "Poppping: " << l.pop() << endl;         // this will give an error at first 
    //// l.print_list(); 

    // Part - 2 Ends here ----------------------

    return 0; 
}