#include <iostream>
#include <string> 
using namespace std; 

// prototype go here 


int main() { 
    string haystack; 
    char needle; 

    // Also try different values for the string and character
    haystack = "A quick brown fox (id: 45) jumped over a lazy dog (id: 9)"; 
    needle = 'j'; 

    int loc, count; 
    loc = index(&haystack[0], needle); 
    cout << "Loc: " << loc << endl; 

    count = count_digits(&haystack[0]); 
    cout << "Count: " << count << endl;  

    return 0; 
}

// functions go here 
