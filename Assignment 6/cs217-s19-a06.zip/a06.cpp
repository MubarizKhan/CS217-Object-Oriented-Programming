#include <iostream> 
using namespace std; 

class List { 
 
};


int main() { 
    List l; 

    l.push(5);          
    l.push(15);
    l.push(30);
    l.push(32);
    l.push(3);
    l.push(29);
    l.print_list(); 

    cout << "Sum = " << l.get_sum() << endl; 

    return 0; 
}
